# Pocket Full of Mary — Early 2000s Forum Theme

A vibrant early-2000s retro forum personal site (`index.html`) and matching Admin Control Panel (`admin/index.html`).

## Privacy & Configuration
- This GitHub version has **no Supabase URL, API keys, passwords, or personal contact details**.
- `index.html` works out of the box as a static site (e.g., on GitHub Pages) using its embedded fallback state.
- To connect your own Supabase backend, set `SB_URL` and `SB_KEY` in `index.html` and `admin/index.html`.
